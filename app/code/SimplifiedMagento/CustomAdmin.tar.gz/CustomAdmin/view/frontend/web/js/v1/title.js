define(function(){
    'use strict';

    return function(config,element){
        element.innerText = "Version 1";
    }
});
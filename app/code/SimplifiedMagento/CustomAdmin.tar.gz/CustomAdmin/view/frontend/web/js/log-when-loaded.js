define(function(){
    'use strict';

    console.log('--module loaded--');
});